
  # Minimalist Personal Portfolio

  This is a code bundle for Minimalist Personal Portfolio. The original project is available at https://www.figma.com/design/P5IYpR2fEQdgmdfrZD4lGj/Minimalist-Personal-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  